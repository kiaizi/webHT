//////////////////////////////////////////////////////////////
Import product data Steps
//////////////////////////////////////////////////////////////


1. 	Download this free FTP software 
	http://filezilla-project.org/download.php?type=client
	install it and login to your web server FTP

	Left hand side is your pc
	Right hand side is the web server



2.	Upload "files" folder with all product's "size and fit" files to the ftp 
	"/domains/noveltylane.com/public_html"

	You would see the product's "size and fit" excel file format in "files/size_and_fit" folder
	


2. 	Follow 
	step/step1.jpg
	step/step 2.jpg 
	to set the folder "files/size_and_fit" chmod to 777 via FTP software 



2.	Then upload your product.xls via backend "SHOP > Products"
	You would see the product data excel format in "sample_product.xls"


